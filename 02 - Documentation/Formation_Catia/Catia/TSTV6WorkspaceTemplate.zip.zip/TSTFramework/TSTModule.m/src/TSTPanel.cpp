// COPYRIGHT Dassault Systemes 2011
//===================================================================
//
// TSTPanel.cpp
//
//===================================================================

#include "TSTPanel.h"

#include "CATApplicationFrame.h"
#include "CATDlgGridConstraints.h"
#include "CATDlgFrame.h"
#include "CATDlgLabel.h"
#include "CATDlgEditor.h"
#include "CATIAlias.h"

CATImplementClass (TSTPanel, Implementation, CATBaseUnknown, CATNull);
 
//-----------------------------------------------------------------------------
// Constructor
//-----------------------------------------------------------------------------
TSTPanel::TSTPanel(): CATDlgDialog((CATApplicationFrame::GetApplicationFrame())->GetMainWindow(), "My Panel", CATDlgWndBtnOKCancel | CATDlgGridLayout)
{
   _pElement           = NULL;
   _pElementNameEditor = NULL;
   _pElementTypeEditor = NULL;

}

//-----------------------------------------------------------------------------
// Destructor
//-----------------------------------------------------------------------------
TSTPanel::~TSTPanel()
{
   if (NULL != _pElement) _pElement -> Release(); _pElement = NULL;
}

//-------------------------------------------------------------------------
// Build
//-------------------------------------------------------------------------
void TSTPanel::Build()
{
   CATDlgLabel * pElementNameLabel = new CATDlgLabel (this, "ElementNameLabel");
   if (NULL == pElementNameLabel)  return;
   pElementNameLabel -> SetGridConstraints (1, 1, 1, 1, CATGRID_LEFT);

   _pElementNameEditor = new CATDlgEditor (this, "ElementNameEditor");
   if (NULL == _pElementNameEditor)  return;
   _pElementNameEditor -> SetGridConstraints (1, 2, 1, 1, CATGRID_4SIDES);

   CATDlgLabel * pElementTypeLabel = new CATDlgLabel (this, "ElementTypeLabel");
   if (NULL == pElementTypeLabel)  return;
   pElementTypeLabel -> SetGridConstraints (2, 1, 1, 1, CATGRID_LEFT);

   _pElementTypeEditor = new CATDlgEditor (this, "ElementTypeEditor");
   if (NULL == _pElementTypeEditor)  return;
   _pElementTypeEditor -> SetGridConstraints (2, 2, 1, 1, CATGRID_4SIDES);

   SetGridColumnResizable (2,1);
}

//-------------------------------------------------------------------------
// Update
//-------------------------------------------------------------------------
void TSTPanel::Update()
{
   if (NULL != _pElementNameEditor) 
   {
      CATUnicodeString ElementName;
      if (NULL != _pElement) 
      {
         CATIAlias_var spAlias = _pElement;
         if (NULL_var != spAlias)  ElementName = spAlias -> GetAlias();
      }
      _pElementNameEditor -> SetText (ElementName);
   }

   if (NULL != _pElementTypeEditor) 
   {
      CATUnicodeString ElementType;
      if (NULL != _pElement) ElementType = _pElement -> GetImpl() -> IsA();
      _pElementTypeEditor -> SetText (ElementType);
   }

   this -> SetVisibility (CATDlgShow);
}

//-------------------------------------------------------------------------
// Cancel
//-------------------------------------------------------------------------
void TSTPanel::Cancel(CATCommand * iCommand, CATNotification * iNotification, CATCommandClientData iUsefulData)
{
	this -> SetVisibility(CATDlgHide);	
	RequestDelayedDestruction();
}

//-------------------------------------------------------------------------
// SetElement
//-------------------------------------------------------------------------
HRESULT TSTPanel::SetElement (CATBaseUnknown * ipElement)
{
   if (NULL != _pElement) _pElement -> Release(); _pElement = NULL;
   _pElement = ipElement;
   if (NULL != _pElement) _pElement -> AddRef();

   return S_OK;
}
