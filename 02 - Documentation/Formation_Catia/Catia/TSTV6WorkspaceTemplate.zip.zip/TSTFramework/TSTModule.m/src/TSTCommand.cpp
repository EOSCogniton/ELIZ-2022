// COPYRIGHT Dassault Systemes 2011
//===================================================================
//
// TSTCommand.cpp
//
//===================================================================

#include "TSTCommand.h" 

#include "TSTPanel.h"

#include "CATBaseUnknown.h"
#include "CATPathElement.h"
#include "CATPathElementAgent.h"
#include "CATStateCancelNotification.h"
#include "CATIPLMNavRepInstance.h"
#include "CATIPLMNavOccurrence.h"
#include "CATFrmEditor.h"
#include "CATHSO.h"
#include "CATIBuildPath.h"
#include "iostream.h"

#include "CATCreateExternalObject.h"
CATCreateClass(TSTCommand); 


//-------------------------------------------------------------------------
// Constructor
//-------------------------------------------------------------------------
TSTCommand::TSTCommand() : CATStateCommand("TSTCommand", CATDlgEngOneShot, CATCommandModeExclusive)
{
   _pPanel = new TSTPanel();

   _pSelectedElement     = NULL;
   _pSelectedRepInstance = NULL;
   _pSelectedOccurrence  = NULL;

   _pSelectAgent = NULL;
   _pOKAgent     = NULL;
   _pCancelAgent = NULL;
}  

//-------------------------------------------------------------------------
// Destructor
//-------------------------------------------------------------------------
TSTCommand::~TSTCommand()
{
	// Delete the panel
   if (NULL != _pPanel) {_pPanel -> RequestDelayedDestruction(); _pPanel = NULL;}

      // Release the pointers
   if (NULL != _pSelectedElement)     {_pSelectedElement     -> Release();  _pSelectedElement     = NULL;}
   if (NULL != _pSelectedRepInstance) {_pSelectedRepInstance -> Release();  _pSelectedRepInstance = NULL;}
   if (NULL != _pSelectedOccurrence)  {_pSelectedOccurrence  -> Release();  _pSelectedOccurrence  = NULL;}

	// Delete the agents
   if (NULL != _pSelectAgent)  {_pSelectAgent  -> RequestDelayedDestruction(); _pSelectAgent = NULL;}
   if (NULL != _pOKAgent)      {_pOKAgent      -> RequestDelayedDestruction(); _pOKAgent     = NULL;}
   if (NULL != _pCancelAgent)  {_pCancelAgent  -> RequestDelayedDestruction(); _pCancelAgent = NULL;}
}

//-------------------------------------------------------------------------
// BuildGraph
//-------------------------------------------------------------------------
void TSTCommand::BuildGraph()
{
   // Define the OK button agent
   _pOKAgent = new CATDialogAgent ("OK");
   _pOKAgent -> AcceptOnNotify (_pPanel, _pPanel -> GetDiaOKNotification());

   // Define the Cancel agent
   _pCancelAgent = new CATDialogAgent ("Cancel");
   _pCancelAgent -> AcceptOnNotify (_pPanel, _pPanel -> GetWindCloseNotification());
   _pCancelAgent -> AcceptOnNotify (_pPanel, _pPanel -> GetDiaCANCELNotification());

   // Define the selection agent
   _pSelectAgent = new CATPathElementAgent ("SelectionAgent");

   // Define the behaviors
   _pSelectAgent -> SetBehavior(CATDlgEngWithCSO | CATDlgEngWithPrevaluation | CATDlgEngNewHSOManager);
   AddCSOClient(_pSelectAgent);

   // Define the states
   CATDialogState * pSelectionState = GetInitialState ("ElementSelection");
   pSelectionState -> AddDialogAgent (_pSelectAgent);
   pSelectionState -> AddDialogAgent (_pOKAgent);	
   pSelectionState -> AddDialogAgent (_pCancelAgent);	

   // Define the transitions
   AddTransition (pSelectionState, pSelectionState, IsOutputSetCondition(_pSelectAgent), Action((ActionMethod)&TSTCommand::ElementSelection, NULL, NULL));
   AddTransition (pSelectionState, NULL,            IsOutputSetCondition(_pOKAgent),     Action((ActionMethod)&TSTCommand::Act_OK,           NULL, NULL));
   AddTransition (pSelectionState, NULL,            IsOutputSetCondition(_pCancelAgent), NULL);	

   // Build the Panel
   if (NULL != _pPanel)
   {
      _pPanel -> Build ();
      _pPanel -> Update ();
   }
}

//-----------------------------------------------------------------------------
// Cancel
//-----------------------------------------------------------------------------
CATStatusChangeRC TSTCommand::Cancel (CATCommand * iCommand, CATNotification * iNotif)
{
   HRESULT RC = S_OK;

   if (_pPanel != NULL)  _pPanel -> SetVisibility (CATDlgHide);

   if (iNotif != NULL && iNotif->IsAKindOf("CATStateCancelNotification"))
   {
      if (((CATStateCancelNotification*)iNotif)->GetType() == CATStateCancelNotification::Interrupt)
         ExecuteUndoAtEnd();
   }
   return (CATStatusChangeRCCompleted);
}

//-------------------------------------------------------------------------
// ElementSelection
//-------------------------------------------------------------------------
CATBoolean TSTCommand::ElementSelection (void * data)
{
   CATBoolean returnCode = FALSE;

   // Check input data
   if (NULL != _pSelectAgent)
   {
      // Intialisation
      returnCode = TRUE;

      // Get the selected Element
      CATPathElement * pPathElement = _pSelectAgent -> GetValue();
      if (NULL != pPathElement)  
      {
         _pSelectedElement     =                          pPathElement -> FindElement (IID_CATBaseUnknown);
         _pSelectedRepInstance = (CATIPLMNavRepInstance*)(pPathElement -> FindElement (IID_CATIPLMNavRepInstance));
         _pSelectedOccurrence  = (CATIPLMNavOccurrence*) (pPathElement -> FindElement (IID_CATIPLMNavOccurrence));
      }
      _pSelectAgent -> InitializeAcquisition();

      if (NULL != _pSelectedElement)
      {
         // Update the panel
         _pPanel -> SetElement (_pSelectedElement);
         _pPanel -> Update ();

         // Highlight the selected Element
         if (FAILED(HighlightElement (_pSelectedOccurrence, _pSelectedRepInstance, _pSelectedElement)))  returnCode = FALSE;
      }
      else  returnCode = FALSE;
   }

   return returnCode;
}
 
//-------------------------------------------------------------------------
// Act_OK
//-------------------------------------------------------------------------
CATBoolean TSTCommand::Act_OK (void * data)
{
   // Check input data
   if (NULL == _pOKAgent) return FALSE;
   _pOKAgent -> InitializeAcquisition();

   // Process the selected element
   cout << "========= Process the selected Element ========" << endl;






   return TRUE;
}

//-----------------------------------------------------------------------------
// HighlightElement 
//-----------------------------------------------------------------------------
HRESULT TSTCommand::HighlightElement (CATBaseUnknown * ipOccurrence, 
                                      CATBaseUnknown * ipRepInstance, 
                                      CATBaseUnknown * ipElement)
{
   HRESULT rc = E_INVALIDARG;
   if (NULL != ipElement)
   {
      rc = S_OK;

      // Retrieve the HSO bag
      CATHSO * pHSO = NULL;
      CATFrmEditor * pEditor = CATFrmEditor::GetCurrentEditor();
      if (NULL != pEditor)  
      {
         pHSO = pEditor -> GetHSO();  
         if (NULL == pHSO)  rc = E_UNEXPECTED;
      }
      else  rc = E_UNEXPECTED;

      // Create the PathElement object corresponding to the selected Element
      CATPathElement * pPathElement = NULL;
      if (SUCCEEDED(rc))  rc = CreatePathElement (&pPathElement, ipOccurrence, ipRepInstance, ipElement);

      // Add the PathElement into the HSO 
      if (SUCCEEDED(rc)) pHSO -> AddElement (pPathElement);
      if (NULL != pPathElement)  {pPathElement -> Release();  pPathElement = NULL;}
   }  
   return rc;
}

//-----------------------------------------------------------------------------
// CreatePathElement 
//-----------------------------------------------------------------------------
HRESULT TSTCommand::CreatePathElement (CATPathElement ** opPathElement, 
                                       CATBaseUnknown  * ipOccurrence, 
                                       CATBaseUnknown  * ipRepInstance, 
                                       CATBaseUnknown  * ipElement)
{
   HRESULT rc = E_INVALIDARG;   
   if (NULL != opPathElement && NULL != ipElement)
   {
      // Initialisation
      *opPathElement = NULL;
      rc = S_OK;

      CATPathElement * pContextualPath = NULL;
      if (NULL != ipOccurrence && NULL != ipRepInstance)
      {
         // Retrieve Product Instance path
         CATPathElement * pProductInstancePath = NULL;
         CATIBuildPath * pProductInstanceBuildPath = NULL; 
         rc = ipOccurrence -> QueryInterface (IID_CATIBuildPath,(void**)&pProductInstanceBuildPath);
         if (SUCCEEDED(rc)) rc = pProductInstanceBuildPath -> ExtractPathElement (NULL, &pProductInstancePath);
         if (NULL != pProductInstanceBuildPath) {pProductInstanceBuildPath -> Release(); pProductInstanceBuildPath = NULL;}

         // Retrieve Representation Instance path
         if (SUCCEEDED(rc))
         {
            CATIBuildPath * pRepresentationInstanceBuildPath = NULL; 
            rc = ipRepInstance -> QueryInterface (IID_CATIBuildPath,(void**)&pRepresentationInstanceBuildPath);
            if (SUCCEEDED(rc)) rc = pRepresentationInstanceBuildPath -> ExtractPathElement (pProductInstancePath, &pContextualPath);
            if (NULL != pRepresentationInstanceBuildPath) {pRepresentationInstanceBuildPath -> Release(); pRepresentationInstanceBuildPath = NULL;}
         }
         if (NULL != pProductInstancePath) {pProductInstancePath -> Release(); pProductInstancePath = NULL;}

         // Retrieve Object path in order to get the Mechanical Part Feature
         CATBaseUnknown * pMechanicalPart = NULL;
         if (SUCCEEDED(rc))
         {
            CATPathElement * pObjectPath = NULL;
            CATIBuildPath * pBuildPath = NULL;
            rc = ipElement -> QueryInterface (IID_CATIBuildPath,(void**)&pBuildPath);
            if (SUCCEEDED(rc)) rc = pBuildPath -> ExtractPathElement (NULL, &pObjectPath);
            pObjectPath -> InitToTopElement();
            pMechanicalPart = pObjectPath -> NextChildElement();
            if (NULL != pBuildPath) {pBuildPath -> Release(); pBuildPath = NULL;}
         }

         // Build Mechanical Part Feature path -> the contextual path has to contain the Mechanical Part Feature
         if (SUCCEEDED(rc))
         {
            pContextualPath -> InitToLeafElement();
            pContextualPath -> AddChildElement (pMechanicalPart);
         }
         if (NULL != pMechanicalPart) {pMechanicalPart -> Release(); pMechanicalPart = NULL;}
      }

      // Retrieve the complete Object path
      if (SUCCEEDED(rc))
      {
         CATIBuildPath * pBuildPath = NULL;
         rc = ipElement -> QueryInterface (IID_CATIBuildPath,(void**)&pBuildPath);

         // Here we finally get the value of opPathElement, our CATPathElement
         if (SUCCEEDED(rc)) rc = pBuildPath -> ExtractPathElement (pContextualPath, opPathElement);

         if (NULL != pBuildPath) {pBuildPath -> Release(); pBuildPath = NULL;}
      }
      if (NULL != pContextualPath) {pContextualPath -> Release(); pContextualPath = NULL;}
   }
   return rc;
}

