// COPYRIGHT Dassault Systemes 2011
//===================================================================
//
// TSTAddin.cpp
//
//=================================================================== 
#include "TSTAddin.h"

#include "CATCreateWorkshop.h"
#include "CATAfrCommandHeader.h"

CATImplementClass (TSTAddin, DataExtension, CATIAfrGeneralWksAddin, TSTAddinLT);

// The toolbar is available in all workbenches
CATImplementBOA (CATIAfrGeneralWksAddin, TSTAddin);

//         or choose specific workbenches:

// The toolbar is available in "Part Design" & "Shape Design" workbenches
//#include "TIE_CATIPrtWksAddin.h"
//TIEchain_CATIPrtWksAddin(TSTAddin);

// The toolbar is available in "Part Design" workbench
//#include "TIE_CATIPrtCfgAddin.h"
//TIEchain_CATIPrtCfgAddin(TSTAddin);

// The toolbar is available in "Shape Design" workbench
//#include "TIE_CATIShapeDesignWorkshopAddin.h"
//TIEchain_CATIShapeDesignWorkshopAddin(TSTAddin);

// The toolbar is available in "Product Structure" workbench
//#include "TIE_CATIPrsConfigurationAddin.h"
//TIEchain_CATIPrsConfigurationAddin(TSTAddin);

// The toolbar is available in all workbenches of the "Product" workshop
//#include "TIE_CATIPRDWorkshopAddin.h"
//TIEchain_CATIPRDWorkshopAddin(TSTAddin);


//-----------------------------------------------------------------------------
// Constructor
//-----------------------------------------------------------------------------
TSTAddin::TSTAddin():CATIAfrGeneralWksAddin()
{
}

//-----------------------------------------------------------------------------
// Destructor
//-----------------------------------------------------------------------------
TSTAddin::~TSTAddin()
{
}

//-----------------------------------------------------------------------------
// CreateCommands
//-----------------------------------------------------------------------------
void TSTAddin::CreateCommands()  
{
   CATAfrCommandHeader::CATCreateCommandHeader ("BasicCmd", "TSTModule", "TSTCommand", (void *)NULL, "TSTAddinHeader", CATFrmAvailable);        
}

//-----------------------------------------------------------------------------
// CreateToolbars
//-----------------------------------------------------------------------------
CATCmdContainer * TSTAddin::CreateToolbars()
{
	NewAccess (CATCmdContainer, pMyToolbar, MyToolbar);			   

	NewAccess (CATCmdStarter, pBasicCmd, BasicCmd);
	SetAccessCommand (pBasicCmd, "BasicCmd");	
	SetAccessChild (pMyToolbar, pBasicCmd);

	AddToolbarView(pMyToolbar,	1,	Left);		

	return pMyToolbar;
}
