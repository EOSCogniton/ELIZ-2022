// COPYRIGHT Dassault Systemes 2011
//===================================================================
//
// TSTPanel.h
//
//===================================================================
#ifndef TSTPanel_H
#define TSTPanel_H

#include "CATDlgDialog.h"

class CATNotification;
class CATBaseUnknown;
class CATDlgEditor;

class TSTPanel: public CATDlgDialog
{
	CATDeclareClass;
	DeclareResource (TSTPanel, CATDlgDialog)
				
public:
	
	TSTPanel ();
	virtual ~TSTPanel ();
	
	void Build();
	void Update();

	void Cancel(CATCommand * iCommand, CATNotification * iNotification, CATCommandClientData iUsefulData);

   HRESULT SetElement (CATBaseUnknown * ipElement);


private:

   CATBaseUnknown * _pElement;

   CATDlgEditor   * _pElementNameEditor;
   CATDlgEditor   * _pElementTypeEditor;

};
#endif
