// COPYRIGHT Dassault Systemes 2011
//===================================================================
//
// TSTAddin.h
//
//===================================================================

#ifndef TSTAddin_H
#define TSTAddin_H

#include "CATIAfrGeneralWksAddin.h"

class CATCmdContainer;

class TSTAddin: public CATIAfrGeneralWksAddin
{
   CATDeclareClass;

public:

   TSTAddin ();
   virtual ~TSTAddin ();

   void              CreateCommands();
   CATCmdContainer * CreateToolbars();


private:  

   TSTAddin (const TSTAddin & iObjectToCopy);  
   TSTAddin & operator = (const TSTAddin & iObjectToCopy);  

};
#endif
