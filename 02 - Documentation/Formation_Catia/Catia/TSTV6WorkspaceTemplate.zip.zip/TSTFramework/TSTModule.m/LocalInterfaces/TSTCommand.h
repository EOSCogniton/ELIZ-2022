// COPYRIGHT Dassault Systemes 2011
//===================================================================
//
// TSTCommand.h
//
//===================================================================

#ifndef TSTCommand_H
#define TSTCommand_H

#include "CATStateCommand.h"

class TSTPanel;

class CATBaseUnknown;
class CATIPLMNavRepInstance;
class CATIPLMNavOccurrence;
class CATPathElement;
class CATPathElementAgent;

class TSTCommand: public CATStateCommand
{
	DeclareResource (TSTCommand, CATStateCommand)
		
public:
	
	TSTCommand();
	virtual ~TSTCommand();

	virtual void BuildGraph(); 
		

private:

   CATBoolean ElementSelection  (void * data);	

   CATBoolean Act_OK  (void * data);	

   CATStatusChangeRC Cancel (CATCommand * iCommand, CATNotification * iNotif);

   HRESULT HighlightElement (CATBaseUnknown * ipOccurrence, 
                             CATBaseUnknown * ipRepInstance, 
                             CATBaseUnknown * ipElement);

   HRESULT CreatePathElement (CATPathElement ** opPathElement, 
                              CATBaseUnknown  * ipOccurrence, 
                              CATBaseUnknown  * ipRepInstance, 
                              CATBaseUnknown  * ipElement);

   TSTPanel              * _pPanel;

   CATBaseUnknown        * _pSelectedElement;
   CATIPLMNavRepInstance * _pSelectedRepInstance;
   CATIPLMNavOccurrence  * _pSelectedOccurrence;

   CATPathElementAgent   * _pSelectAgent;
   CATDialogAgent        * _pOKAgent;
   CATDialogAgent        * _pCancelAgent;

};
#endif
