//===================================================================
// COPYRIGHT DASSAULT SYSTEMES 2011
//===================================================================
	
AddPrereqComponent ("System",                       Public);
AddPrereqComponent ("ObjectModelerBase",            Public); 
AddPrereqComponent ("DialogEngine",                 Public);
AddPrereqComponent ("Dialog",                       Public); 
AddPrereqComponent ("AfrFoundation",                Public); 
AddPrereqComponent ("VisualizationInterfaces",      Public); 
AddPrereqComponent ("AfrInterfaces",                Public); 
AddPrereqComponent ("ObjectModelerSystem",          Public); 
AddPrereqComponent ("VisualizationController",      Public); 
AddPrereqComponent ("CATPLMComponentInterfaces",    Public); 

